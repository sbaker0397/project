package com.example.android_todo_first;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private String[] mTodos;
    private int mTodoIndex = 0;

    public static Intent newIntent(Context packageContext, int mTodoIndex){
        Intent intent = newIntent(packageContext, MainActivity.class);
        intent.putExtra(TODO_INDEX, mTodoIndex);
        return intent;
    }

    private static final String TODO_INDEX = "com.example.android_todo_first.todoIndex";

    //state change,
    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt(TODO_INDEX, mTodoIndex);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        if (savedInstanceState != null){
            mTodoIndex=savedInstanceState.getInt(TODO_INDEX, 0);
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView TodoTextView;
        TodoTextView = (TextView) findViewById(R.id.textViewTODO);


        Resources res = getResources();
        mTodos = res.getStringArray(R.array.todos);

        TodoTextView.setText(mTodos[mTodoIndex]);

        Button buttonNEXT;
        buttonNEXT = (Button) findViewById(R.id.buttonNext);

        buttonNEXT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTodoIndex = (mTodoIndex + 1) % mTodos.length;
                TodoTextView.setText(mTodos[mTodoIndex]);
            }
        }
        );

        Button buttonPrev;
        buttonPrev = (Button) findViewById(R.id.buttonPrev);

        buttonPrev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTodoIndex--;
                mTodoIndex = (mTodoIndex > mTodos.length) ? 0 : mTodoIndex + 1;
                mTodoIndex = (mTodoIndex - 1 < 0) ? mTodos.length - 1 : mTodoIndex - 1;
                TodoTextView.setText(mTodos[mTodoIndex]);

            }
        });

    }
}
